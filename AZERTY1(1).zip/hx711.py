import time
from machine import Pin

class HX711:
    def __init__(self, d_out, pd_sck):
        self.d_out = Pin(d_out, Pin.IN)
        self.pd_sck = Pin(pd_sck, Pin.OUT)
        self.reference_unit = 1

    def set_scale(self, reference_unit):
        self.reference_unit = reference_unit

    def get_units(self, times=3):
        values = [self.read() for _ in range(times)]
        return sum(values) / len(values) / self.reference_unit

    def read(self):
        while self.d_out.value():
            pass

        data = 0
        for _ in range(24):
            self.pd_sck.on()
            data = (data << 1) | self.d_out.value()
            self.pd_sck.off()

        self.pd_sck.on()
        data ^= 0x800000  # Complément à 2
        self.pd_sck.off()
        
        return data

    def tare(self, times=10):
        offset = sum(self.read() for _ in range(times)) / times
        self.reference_unit = offset
