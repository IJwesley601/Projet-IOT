import network
import time
import urequests
from machine import Pin, SoftI2C, ADC
import dht
from i2c_lcd import I2cLcd

# 📶 Configuration WiFi
SSID = "Wokwi-GUEST"
PASSWORD = ""

print("Connexion WiFi en cours", end="")
sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
sta_if.connect(SSID, PASSWORD)

while not sta_if.isconnected():
    print(".", end="")
    time.sleep(0.5)

print(" Connecté !")

# 🌍 Configuration de ThingSpeak
THINGSPEAK_API_KEY = "MZYCBLKPZ1IP9YHR"  # Remplace par ta clé API
THINGSPEAK_URL = "https://api.thingspeak.com/update"

# 🌡️ Capteur DHT22
dht_sensor = dht.DHT22(Pin(15))  # Broche D15

# ⚖️ Capteur HX711
class HX711:
    def __init__(self, dout, pd_sck):
        self.dout = Pin(dout, Pin.IN)
        self.pd_sck = Pin(pd_sck, Pin.OUT)
        self.pd_sck.value(0)
        self.scale = 1
        self.offset = 0

    def read(self):
        while self.dout.value():
            pass
        data = 0
        for _ in range(24):
            self.pd_sck.value(1)
            data = (data << 1) | self.dout.value()
            self.pd_sck.value(0)
        self.pd_sck.value(1)
        self.pd_sck.value(0)
        if data & 0x800000:
            data -= 0x1000000
        return data

    def set_scale(self, scale):
        self.scale = scale

    def tare(self):
        self.offset = self.read()

    def get_units(self, times=1):
        value = self.read() - self.offset
        return value / self.scale

hx = HX711(dout=4, pd_sck=5)  # Broches D5 (DT) et D6 (SCK)
hx.set_scale(2280)  # Ajuster selon la calibration
hx.tare()

# 🛑 Capteur MQ-2
mq2_sensor = ADC(Pin(34))  # Broche A0 (34) pour la sortie analogique du MQ-2
mq2_sensor.atten(ADC.ATTN_11DB)  # Plage de mesure : 0-3.3V

# 🖥️ Configuration de l'écran LCD 16x2
i2c = SoftI2C(scl=Pin(22), sda=Pin(21), freq=100000)  # Fréquence réduite à 100 kHz
lcd = I2cLcd(i2c, 0x27, 2, 16)  # Adresse I2C : 0x27

# 📊 Lecture des capteurs
def read_dht22():
    try:
        dht_sensor.measure()
        return dht_sensor.temperature(), dht_sensor.humidity()
    except:
        return None, None

def read_hx711():
    try:
        return hx.get_units(5)  # Lire la pression
    except:
        return None

def read_mq2():
    try:
        return mq2_sensor.read()  # Lire la valeur analogique du MQ-2
    except:
        return None

def estimate_air_quality(gas_value):
    if gas_value > 2000:
        return "Mauvaise"
    elif gas_value > 1000:
        return "Moyenne"
    else:
        return "Bonne"

# 📡 Envoi des données vers ThingSpeak
def send_data(temp, hum, press, gas):
    url = f"{THINGSPEAK_URL}?api_key={THINGSPEAK_API_KEY}&field1={temp}&field2={hum}&field3={press}&field4={gas}"
    try:
        response = urequests.get(url)
        print("ThingSpeak:", response.text)  # Doit afficher un numéro (1, 2, 3...)
        response.close()
    except Exception as e:
        print("Erreur d'envoi:", e)

# 📟 Affichage sur LCD
def display_data(temp, hum, press, air_quality):
    lcd.clear()
    lcd.putstr("Temp: {:.1f}C".format(temp))
    lcd.move_to(0, 1)
    lcd.putstr("Hum: {:.1f}%".format(hum))
    time.sleep(2)

    lcd.clear()
    lcd.putstr("Press: {:.2f}g".format(press))  # Ajuster unité
    time.sleep(2)

    lcd.clear()
    lcd.putstr("Air: {}".format(air_quality))
    time.sleep(2)

# 🔄 Boucle principale
while True:
    temperature, humidity = read_dht22()
    pressure = read_hx711()
    gas_value = read_mq2()
    air_quality = estimate_air_quality(gas_value)

    if temperature is not None and humidity is not None and pressure is not None and gas_value is not None:
        display_data(temperature, humidity, pressure, air_quality)
        send_data(temperature, humidity, pressure, gas_value)

    time.sleep(15)  # Attendre 15 secondes avant la prochaine lecture
