"use client"

import { useState, useEffect } from "react"
import { collection, query, orderBy, limit, onSnapshot } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Thermometer, Droplets, Wind, Gauge, Sun, CloudRain } from "lucide-react"
import WeatherChart from "@/components/dashboard/weather-chart"

type WeatherData = {
  timestamp: { seconds: number }
  temperature: number
  humidity: number
  pressure: number
  windSpeed: number
  windDirection: number
  rainfall: number
  light: number
}

export default function WeatherDisplay() {
  const [currentData, setCurrentData] = useState<WeatherData | null>(null)
  const [historicalData, setHistoricalData] = useState<WeatherData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Subscribe to the latest weather data
    const latestDataQuery = query(collection(db, "weatherData"), orderBy("timestamp", "desc"), limit(1))

    const latestUnsubscribe = onSnapshot(latestDataQuery, (snapshot) => {
      if (!snapshot.empty) {
        const data = snapshot.docs[0].data() as WeatherData
        setCurrentData(data)
      }
      setLoading(false)
    })

    // Subscribe to historical data (last 24 hours)
    const historicalDataQuery = query(collection(db, "weatherData"), orderBy("timestamp", "desc"), limit(24))

    const historicalUnsubscribe = onSnapshot(historicalDataQuery, (snapshot) => {
      const data = snapshot.docs.map((doc) => doc.data() as WeatherData)
      setHistoricalData(data.reverse()) // Reverse to get chronological order
    })

    return () => {
      latestUnsubscribe()
      historicalUnsubscribe()
    }
  }, [])

  // For demo purposes, generate mock data if no data exists
  useEffect(() => {
    if (loading && !currentData) {
      const mockData: WeatherData = {
        timestamp: { seconds: Date.now() / 1000 },
        temperature: 22.5,
        humidity: 65,
        pressure: 1013,
        windSpeed: 12,
        windDirection: 180,
        rainfall: 0,
        light: 75,
      }

      setCurrentData(mockData)

      const mockHistorical = Array.from({ length: 24 }, (_, i) => ({
        ...mockData,
        timestamp: { seconds: Date.now() / 1000 - i * 3600 },
        temperature: 20 + Math.random() * 5,
        humidity: 60 + Math.random() * 10,
        pressure: 1010 + Math.random() * 10,
        windSpeed: 10 + Math.random() * 5,
        rainfall: Math.random() < 0.3 ? Math.random() * 2 : 0,
      }))

      setHistoricalData(mockHistorical.reverse())
      setLoading(false)
    }
  }, [loading, currentData])

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Tableau de bord météo</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Thermometer className="mr-2 h-4 w-4 text-red-500" />
              Température
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentData?.temperature.toFixed(1)}°C</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Droplets className="mr-2 h-4 w-4 text-blue-500" />
              Humidité
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentData?.humidity.toFixed(0)}%</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Gauge className="mr-2 h-4 w-4 text-purple-500" />
              Pression
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentData?.pressure.toFixed(0)} hPa</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Wind className="mr-2 h-4 w-4 text-cyan-500" />
              Vent
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentData?.windSpeed.toFixed(1)} km/h</div>
            <div className="text-xs text-muted-foreground">
              Direction: {getWindDirection(currentData?.windDirection || 0)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <CloudRain className="mr-2 h-4 w-4 text-blue-600" />
              Précipitations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentData?.rainfall.toFixed(1)} mm</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Sun className="mr-2 h-4 w-4 text-yellow-500" />
              Luminosité
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentData?.light.toFixed(0)}%</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="temperature" className="w-full">
        <TabsList className="grid grid-cols-3 md:grid-cols-6">
          <TabsTrigger value="temperature">Température</TabsTrigger>
          <TabsTrigger value="humidity">Humidité</TabsTrigger>
          <TabsTrigger value="pressure">Pression</TabsTrigger>
          <TabsTrigger value="wind">Vent</TabsTrigger>
          <TabsTrigger value="rainfall">Précipitations</TabsTrigger>
          <TabsTrigger value="light">Luminosité</TabsTrigger>
        </TabsList>

        <TabsContent value="temperature">
          <Card>
            <CardHeader>
              <CardTitle>Évolution de la température</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart data={historicalData} dataKey="temperature" color="#ef4444" unit="°C" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="humidity">
          <Card>
            <CardHeader>
              <CardTitle>Évolution de l'humidité</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart data={historicalData} dataKey="humidity" color="#3b82f6" unit="%" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pressure">
          <Card>
            <CardHeader>
              <CardTitle>Évolution de la pression</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart data={historicalData} dataKey="pressure" color="#8b5cf6" unit="hPa" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="wind">
          <Card>
            <CardHeader>
              <CardTitle>Évolution du vent</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart data={historicalData} dataKey="windSpeed" color="#06b6d4" unit="km/h" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rainfall">
          <Card>
            <CardHeader>
              <CardTitle>Évolution des précipitations</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart data={historicalData} dataKey="rainfall" color="#2563eb" unit="mm" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="light">
          <Card>
            <CardHeader>
              <CardTitle>Évolution de la luminosité</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart data={historicalData} dataKey="light" color="#eab308" unit="%" />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function getWindDirection(degrees: number): string {
  const directions = ["N", "NE", "E", "SE", "S", "SO", "O", "NO"]
  const index = Math.round(degrees / 45) % 8
  return directions[index]
}

